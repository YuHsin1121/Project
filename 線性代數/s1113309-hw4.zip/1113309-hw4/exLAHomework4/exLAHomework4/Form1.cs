﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exLAHomework4
{
    public partial class Form1 : Form
    {
        Bitmap _bmpBG = new Bitmap(800, 600);
        Bitmap _bmp = new Bitmap(800, 600);        
        Point _ptS = new Point();
        Point _ptE = new Point();
        bool _draw = false;
        ArrayList _ptList = new ArrayList();

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            _bmp = (Bitmap) _bmpBG.Clone();
            _ptS.X = e.X;
            _ptS.Y = e.Y;
            _draw = true;
            _ptList.Add(e.Location);
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            _ptE.X = e.X;
            _ptE.Y = e.Y;
            _draw = false;
            if (this.comboBox1.Text == "Line") CalculatelLine(_ptS, _ptE);
            if (this.comboBox1.Text == "Triangle")
            {
                DrawTriangle(_ptList);
                CalculateTriangle();
            }
            if (this.comboBox1.Text == "Rectangle")
            {
                DrawRectangle(_ptList);
                CalculateRectangle();
            }
            if (this.comboBox1.Text == "Pentagon")
            {
                DrawPentagon(_ptList);
                CalculatePentagon();
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (this.comboBox1.Text == "Line")
            {
                if (!_draw) return;
                DrawLine(_ptS, new Point(e.X, e.Y));
            }
        }

        private void CalculatelLine(Point ptS, Point ptE)
        {
            double X2 = Math.Pow(ptS.X - ptE.X, 2);
            double Y2 = Math.Pow(ptS.Y - ptE.Y, 2);
            double dist = Math.Sqrt(X2 + Y2);
            string strLog1 = string.Format("From ({0},{1}) to ({2},{3}) dist={4} \r\n", ptS.X, ptS.Y, ptE.X, ptE.Y, dist);
            string strLog2 = string.Format("Area = 0 \r\n\r\n");
            this.textBox1.Text += strLog1+strLog2 ;
        }
        private void DrawLine(Point ptS,Point ptE)
        {
            _bmp = (Bitmap) _bmpBG.Clone();
            Graphics g = Graphics.FromImage(_bmp);
            //g.Clear(Color.White);
            Pen pen = new Pen(Color.Purple, 3);
            g.DrawLine(pen, ptS, ptE);
            this.pictureBox1.Image = _bmp;
        }

        /**/
        private double TwoPointsDistance(Point pt1,Point pt2)
        {
            double x = Math.Pow(pt1.X - pt2.X, 2);
            double y = Math.Pow(pt1.Y - pt2.Y, 2);
            return Math.Sqrt(x + y);
        }

        private void CalculateTriangle()
        {
            if (_ptList.Count < 3) return;
            double distTotal = 0;
            for(int idxS=0; idxS < 3; idxS++)
            {
                int idxE = (idxS + 1) % 3;
                double X2 = Math.Pow(((Point)_ptList[idxS]).X - ((Point)_ptList[idxE]).X, 2);
                double Y2 = Math.Pow(((Point)_ptList[idxS]).Y - ((Point)_ptList[idxE]).Y, 2);
                double dist = Math.Sqrt(X2 + Y2);
                distTotal += dist;
            }

            double a = TwoPointsDistance((Point)_ptList[0], (Point)_ptList[1]);
            double b = TwoPointsDistance((Point)_ptList[1], (Point)_ptList[2]);
            double c = TwoPointsDistance((Point)_ptList[2], (Point)_ptList[0]);

            double s = (a + b + c) / 2;
            double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));

            string strLog1 = string.Format("total dist={0} \r\n", distTotal);
            string strLog2 = string.Format("Area = {0} \r\n\r\n", area);
            this.textBox1.Text += strLog1 + strLog2;
            DrawTriangle(_ptList);
            _ptList.Clear();
        }

        private void DrawTriangle(ArrayList list)
        {
            _bmp = (Bitmap)_bmpBG.Clone();
            Graphics g = Graphics.FromImage(_bmp);            
            Pen pen = new Pen(Color.Purple, 3);
            for(int i=0;i<list.Count;i++)
            {
                Point pt1 = (Point)list[i];
                g.DrawEllipse(pen,pt1.X,pt1.Y  ,3,3);

                //if (list.Count<=2) continue;
                int idxE = (i + 1) % 3;
                if (idxE >= list.Count) continue;
                Point pt2 = (Point)list[idxE];
                g.DrawLine(pen, pt1,pt2);
            }            
            this.pictureBox1.Image = _bmp;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() != DialogResult.OK) return;
            string file = dlg.FileName;
            Bitmap bmp = (Bitmap)Image.FromFile(file);
            double ratioX = (double)bmp.Width / 800;
            double ratioY = (double)bmp.Height / 600;
            double scale = Math.Max(ratioX, ratioY);
            _bmpBG = new Bitmap(bmp, new Size((int)(bmp.Width / scale), (int)(bmp.Height / scale)));
            this.pictureBox1.Image = _bmpBG;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            _ptList.Clear();
        }

        /**/
        private void DrawRectangle(ArrayList list)
        {
            _bmp=(Bitmap)_bmpBG.Clone();
            Graphics g= Graphics.FromImage(_bmp);
            Pen pen = new Pen(Color.Purple, 3);

            if (list.Count >= 2)
            {
                Point pt1 = (Point)list[0];
                g.DrawEllipse(pen, pt1.X, pt1.Y, 3, 3);
                Point pt2 = (Point)list[1];
                g.DrawEllipse(pen, pt2.X, pt2.Y, 3, 3);
                g.DrawRectangle(pen, Math.Min(pt1.X, pt2.X), Math.Min(pt1.Y, pt2.Y), Math.Abs(pt1.X - pt2.X), Math.Abs(pt1.Y - pt2.Y));
            }

            this.pictureBox1.Image = _bmp;
        }

        private void CalculateRectangle()
        {
            if (_ptList.Count < 2) return;

            Point pt1 = (Point)_ptList[0];
            Point pt2 = (Point)_ptList[1];

            double width = Math.Abs(pt1.X - pt2.X);
            double height = Math.Abs(pt1.Y - pt2.Y);

            double distance = 2 * (width + height);
            double area = width * height;

            string strLog1 = string.Format("total dist={0}\r\n", distance);
            string strLog2 = string.Format("Area={0}\r\n\r\n", area);
            this.textBox1.Text += strLog1 + strLog2;
            DrawRectangle(_ptList);
            _ptList.Clear();
        }

        private void DrawPentagon(ArrayList list)
        {
            _bmp = (Bitmap)_bmp.Clone();
            Graphics g = Graphics.FromImage(_bmp);
            Pen pen = new Pen(Color.Purple, 3);

            if (list.Count >= 5)
            {
                Point[] points = new Point[5];
                for (int i = 0; i < 5; i++)
                {
                    points[i] = (Point)list[i];
                    g.DrawEllipse(pen, points[i].X, points[i].Y, 3, 3);
                }

                g.DrawPolygon(pen, points);
            }

            this.pictureBox1.Image = _bmp;
        }

        private void CalculatePentagon()
        {
            if (_ptList.Count != 5) return;

            double distance = 0;
            for (int i = 0; i < 5; i++)
            {
                int next = (i + 1) % 5;
                distance += TwoPointsDistance((Point)_ptList[i], (Point)_ptList[next]);
            }

            double c = CalculateCenter(_ptList);
            double area = (distance * c) / 2;

            string strLog1 = string.Format("total dist= {0}\r\n", distance);
            string strLog2 = string.Format("Area={0}\r\n\r\n", area);
            this.textBox1.Text += strLog1 + strLog2;
            DrawPentagon(_ptList);
            _ptList.Clear();
        }

        private double CalculateCenter(ArrayList list)
        {
            Point c = new Point(
                (int)(list.Cast<Point>().Sum(p => p.X) / 5.0),
                (int)(list.Cast<Point>().Sum(p => p.Y) / 5.0)
            );

            return TwoPointsDistance(c, (Point)list[0]);
        }
    }
}